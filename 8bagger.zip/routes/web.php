<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PagesController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\ClassController;
use App\Http\Controllers\CommentsController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [PagesController::class, 'index']);

Route::get('article', [PagesController::class, 'article']);

Route::get('class', [PagesController::class, 'class']);

Route::get('article/detail', [PagesController::class, 'detail']);

Route::get('article', [ArticleController::class, 'getArticle']);

Route::get('article/detail/{id}', [ArticleController::class, 'getDetailArticle']);

//Classes
Route::get('class', [ClassController::class, 'getClass']);

// Comments
Route::post('article/detail/{article_id}/comment',[CommentsController::class, 'store'])->name('comments.store');

Auth::routes();

