

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center bg-gray-50 mt-10 py-10">
        <div class="text-center w-1/4 mt-10">
            <h1 class="text-4xl sm:text-3xl w-25 font-semibold">
                Article
            </h1>
            <hr class="border-b-4 logo-border-color mt-5">
        </div>
    </div>

    <div class="container w-full mx-auto px-4 md:px-12">
        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Column -->
            <div class="my-2 px-1 w-full lg:my-4 lg:px-4">

                <!-- Article -->
                <article class="overflow-hidden grid lg:grid-cols-2 p-6 rounded-lg shadow-lg">
                    <a href="article/detail/<?php echo e($article->id); ?>">
                        <img alt="" class="block h-full w-full" src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($article->images); ?>">
                    </a>
                    <div class="block h-auto w-full">
                        <header class="flex block xs:h-12 h-16 leading-tight p-2 md:p-4">
                            <h1 class="text-lg logo-text-color px-6">
                                <?php echo e($article->title); ?>

                            </h1>
                        </header>
                        <p class="block h-auto ml-2 md:ml-4 text-sm sm:text-md px-6 leading-normal">
                            By : <?php echo e($article->author); ?>

                        </p>
                        <p class="block h-auto ml-2 md:ml-4 text-sm sm:text-md px-6 leading-normal">
                            <?php echo e($article->date); ?>

                        </p>
                        <p class="block text-justify h-auto ml-2 md:ml-4 text-sm sm:text-md px-6 py-2 leading-normal">
                            <?php echo e($article->summary); ?>

                        </p>
                        <footer class="flex items-center justify-between leading-none ml-6 p-2 pb-3 md:p-4">
                            <a href="article/detail/<?php echo e($article->id); ?>" class="py-2 text-blue-400 hover:underline">See More</a>
                        </footer>
                    </div>
                </article>
                <!-- END Article -->
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="flex m-auto p-2 justify-center">
        <?php echo e($articles->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1046716/public_html/resources/views/article/index.blade.php ENDPATH**/ ?>