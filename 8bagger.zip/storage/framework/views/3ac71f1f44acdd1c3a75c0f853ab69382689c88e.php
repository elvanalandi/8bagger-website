

<?php $__env->startSection('content'); ?>
    <div class="bg-gray-100">
        <div class="m-auto w-25 w-4/5 mt-2 py-10">
            <h1 class="w-full text-5xl font-extrabold py-5">Your
                <span class="font-extrabold logo-text-color">
                    Stock Investment
                </span>
            </h1>
            <h1 class="sm:w-full md:w-1/2 lg:w-1/2 text-5xl font-extrabold">
                Guidance
            </h1>
            <p class="text-justify sm:w-full md:w-1/2 lg:w-1/2 leading-loose pb-10 pt-10">
                At 8BAGGERS we know you are the kind of people who want to be a Better Value Investor. In order to be that way, 
                <u>you need to be good at your own stock analysis</u>. The problem is there is so many 
                <u>companies that looks undervalued</u> that can be a <u>value trap</u>. 
                Which makes you confused to identify "the real one". We believe to be a<u>good independent investor</u>  
                is not an easy task. We understand that you need<u>a guide to lead your step by step investing journey</u> . 
                Thats why we present to you our <i class="logo-text-color sm:text-s">8BAGGERS Value Investing Camp</i></b>, to help you to be a 
                <i class="logo-text-color sm:text-s">Independent Value Investor</i></b>.
            </p>
            <button type="button" class="gradient-color px-5 py-5 rounded-xl">
                <a href="https://linktr.ee/8baggersServices" class="text-gray-50 sm:text-l">
                    Register Now
                </a>
            </button>
        </div>
    </div>

    <div class="flex justify-center bg-gray-50 mt-10 py-10">
        <div class="text-center w-1/4 mt-10">
            <h1 class="text-4xl sm:text-3xl w-25 font-semibold">
                Article
            </h1>
            <hr class="border-b-4 logo-border-color mt-5">
        </div>
    </div>

    <div class="container mx-auto px-4 md:px-12">
        <div class="flex flex-wrap -mx-1 lg:-mx-4">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Column -->
            <div class="my-2 px-1 w-full md:w-1/2 lg:my-4 lg:px-4 lg:w-1/3">

                <!-- Article -->
                <article class="overflow-hidden rounded-lg shadow-lg">
                    <img alt="" class="block h-auto w-full pb-4" src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($article->images); ?>">

                    <header class="flex items-center block h-12 justify-between leading-tight p-2 md:p-4">
                        <h1 class="text-lg logo-text-color px-6">
                            <?php echo e($article->title); ?>

                        </h1>
                    </header>
                    <p class="block h-48 ml-2 md:ml-4 text-sm sm:text-md text-justify px-6 py-2 leading-normal">
                        <?php echo e($article->summary); ?>

                    </p>
                    <footer class="flex items-center justify-between leading-none ml-6 p-2 pb-3 md:p-4">
                        <button type="button" class="bg-blue-700 p-2 rounded-lg">
                        <a href="article/detail/<?php echo e($article->id); ?>" class="px-2 py-2 text-gray-50">See More</a>
                        </button>
                    </footer>

                </article>
                <!-- END Article -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="flex justify-center bg-gray-50 mt-10 py-10">
        <div class="text-center w-1/4 mt-10">
            <h1 class="text-2xl sm:text-4xl w-25 font-semibold">
                Benefit
            </h1>
            <hr class="border-b-4 logo-border-color mt-5">
        </div>
    </div>

    <h1 class="text-center text-2xl sm:text-xl font-semibold leading-normal p-4">
        Being A Good Independent Investor Is Not That Easy
    </h1>
    
    <h2 class="text-center text-xl sm:text-lg leading-normal py-4 px-10">
        It’s a fact that, you need a “complete” investing knowledge to be better at stock investing. 
        At 8BAGGERS Value Investing Camp, we have the tools that you needed to help you start your stock investing journey. 
        So you can be a good independent investor.
    </h2>

    <h2 class="text-center text-xl sm:text-lg leading-normal py-4 px-10">
        Have you been frustrated by class who :
    </h2>

    <div class="flex justify-center">
        <div class="grid grid-cols-2 mt-10 justify-center mx-10">
            <div class="">
                <ul class="list-inside list-disc p-4 leading-normal">
                    <li>Has a Miserable Teaching Steps</li>
                    <li>Not a Pure Value Investing</li>
                    <li>Teaching a Technical Analysis</li>
                </ul>
            </div>
            <div class="">
                <ul class="list-inside list-disc p-4 leading-normal">
                    <li>Non-downloadable handbook</li>
                    <li>Can't help you to be an independent investor</li>
                    <li>Selling their  stockpick to you</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="flex justify-center mt-10">
        <button type="button" class="gradient-color px-5 py-5 rounded-xl">
            <a href="https://linktr.ee/8baggersServices" class="text-gray-50 sm:text-l">
                Register Now
            </a>
        </button>
    </div>

    <div class="flex justify-center bg-gray-50 mt-10 py-10">
        <div class="text-center w-1/4 mt-10">
            <h1 class="text-2xl sm:text-4xl w-25 font-semibold">
                Testimoni
            </h1>
            <hr class="border-b-4 content-center logo-border-color  mt-5">
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1046716/public_html/resources/views/index.blade.php ENDPATH**/ ?>