<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', '8Baggers')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link
      rel="stylesheet"
      href="https://use.fontawesome.com/releases/v5.13.0/css/all.css"
      integrity="sha384-Bfad6CLCknfcloXFOyFnlgtENryhrpZCe29RTifKEixXQZ38WheV+i/6YWSzkz3V"
      crossorigin="anonymous"
    />

</head>
<body class="bg-gray-50 h-screen antialiased leading-none font-sans">
    <div id="app">
        <header class="bg-gray-50 py-6 shadow-lg">
            <div class="container mx-auto flex justify-between items-center px-6">
                <a href="<?php echo e(url('/')); ?>" class="text-lg font-semibold text-gray-100 no-underline">
                    <img src="<?php echo e(URL::asset('/images/8baggers.png')); ?>" class="w-36 md:w-48 lg:w-60">
                </a>
                
                <nav class="space-x-4 absolute right-10 text-gray-400 text-sm sm:text-s">
                    <div class="flex items-center justify-center sm:items-stretch sm:justify-start">
                        <div class="hidden sm:block sm:ml-6">
                            <div class="flex space-x-4">
                                <a href="/" class="text-lg text-center p-4 no-underline hover:underline" aria-current="page">Home</a>
                                <a href="/article" class="text-lg text-center p-4 no-underline hover:underline">Article</a>
                                <a href="/class" class="text-lg text-center p-4 no-underline hover:underline">Our Class</a>
                                <button type="button" class="gradient-color p-4 rounded-xl">
                                    <a href="https://linktr.ee/8baggersServices" class=" text-gray-50 text-lg no-underline hover:underline">Register</a>
                                </button>
                            </div>
                        </div>
                    </div>
                </nav>

                <!-- Mobile Menu -->
                <div class="mr-8">
                    <div class="dropdown sm:hidden inline-block relative">
                        <button class="bg-gray-300 text-gray-700 font-semibold py-2 px-4 rounded inline-flex items-center">
                            <i class="fas fa-bars" style="font-size: 25px; color: #169bd7"></i>
                        </button>
                        <ul class="dropdown-menu absolute hidden text-gray-700 pt-1">
                            <li class=""><a href="/" class="rounded-t bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap" aria-current="page">Home</a></li>
                            <li class=""><a href="/article" class="rounded-t bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap">Article</a></li>
                            <li class=""><a href="/class" class="rounded-t bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap">Our Class</a></li>
                            <li class=""><a href="https://linktr.ee/8baggersServices" class="rounded-t bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap">Register</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>

        <div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Project\laravel\8bagger\resources\views/layouts/app.blade.php ENDPATH**/ ?>