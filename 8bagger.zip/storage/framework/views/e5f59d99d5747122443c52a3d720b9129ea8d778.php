

<?php $__env->startSection('content'); ?>
    <div class="flex justify-center bg-gray-50 mt-10 py-10">
        <div class="text-center w-1/4 mt-10">
            <h1 class="text-4xl sm:text-3xl w-25 font-semibold">
                Our Class
            </h1>
            <hr class="border-b-4 logo-border-color mt-5">
        </div>
    </div>

    <div class="container grid lg:grid-cols-3 w-full mx-auto px-4 md:px-12">
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Column -->
            
                <div class="my-2 px-1 w-full lg:my-4 lg:px-4">

                    <a href="#<?php echo e($class->id); ?>">
                        <!-- Article -->
                        <article class="overflow-hidden p-6 rounded-lg shadow-lg">
                            
                            <img alt="" class="block h-32 w-full" src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($class->images); ?>">
                            
                            <div class="block h-auto w-full" id="<?php echo e($class->id); ?>">
                                <header class="block text-center h-12 leading-tight p-2 md:p-4">
                                    <h1 class="text-lg font-semibold px-6">
                                        <?php echo e($class->title); ?>

                                    </h1>
                                </header>
                                <p class="block text-center logo-text-color h-12 text-sm sm:text-md px-6 leading-normal">
                                    <?php echo e($class->description); ?>

                                </p>
                            </div>
                        </article>
                        <!-- END Article -->
                    </a>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="flex justify-center bg-gray-50 mt-10 py-10">
        <div class="text-center w-1/4 mt-10">
            <h1 class="text-4xl sm:text-3xl w-25 font-semibold">
                Detail Class
            </h1>
            <hr class="border-b-4 logo-border-color mt-5">
        </div>
    </div>

    <div class="container w-full mx-auto px-4 md:px-12">
        <!-- Column -->
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="my-2 px-1 w-full lg:my-4 lg:px-4">
        <!-- Article -->
            <article class="overflow-hidden items-center p-6" id="<?php echo e($class->id); ?>">
                <img alt="" class="h-32 w-60 m-auto" src="<?php echo e(URL::to('/')); ?>/images/<?php echo e($class->images); ?>">

                <div class="h-auto w-full">
                    <header class="text-center h-12 leading-tight p-2 md:p-4">
                        <h1 class="text-lg logo-text-color font-semibold px-6">
                            <?php echo e($class->title); ?>

                        </h1>
                    </header>
                    <p class="text-center h-12 text-sm sm:text-md px-6 leading-normal">
                        <?php echo e($class->description); ?>

                    </p>
                    <div class="h-auto ml-2 md:ml-4 text-sm sm:text-md px-6 py-6 leading-relaxed">
                        <?php echo $class->body; ?>

                    </div>
                </div>
            </article>
            <!-- END Article -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\laravel\8bagger\resources\views/class/index.blade.php ENDPATH**/ ?>