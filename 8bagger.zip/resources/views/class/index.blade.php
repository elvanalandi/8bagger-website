@extends('layouts.app')

@section('content')
    <div class="flex justify-center bg-gray-50 mt-10 py-10">
        <div class="text-center w-1/4 mt-10">
            <h1 class="text-4xl sm:text-3xl w-25 font-semibold">
                Our Class
            </h1>
            <hr class="border-b-4 logo-border-color mt-5">
        </div>
    </div>

    <div class="container grid lg:grid-cols-3 w-full mx-auto px-4 md:px-12">
        @foreach ($classes as $class)
            <!-- Column -->
            
                <div class="my-2 px-1 w-full lg:my-4 lg:px-4">

                    <a href="#{{$class->id}}">
                        <!-- Article -->
                        <article class="overflow-hidden p-6 rounded-lg shadow-lg">
                            
                            <img alt="" class="block h-32 w-full" src="{{URL::to('/') }}/images/{{$class->images}}">
                            
                            <div class="block h-auto w-full" id="{{$class->id}}">
                                <header class="block text-center h-12 leading-tight p-2 md:p-4">
                                    <h1 class="text-lg font-semibold px-6">
                                        {{$class->title}}
                                    </h1>
                                </header>
                                <p class="block text-center logo-text-color h-12 text-sm sm:text-md px-6 leading-normal">
                                    {{$class->description}}
                                </p>
                            </div>
                        </article>
                        <!-- END Article -->
                    </a>
                </div>
        @endforeach
    </div>

    <div class="flex justify-center bg-gray-50 mt-10 py-10">
        <div class="text-center w-1/4 mt-10">
            <h1 class="text-4xl sm:text-3xl w-25 font-semibold">
                Detail Class
            </h1>
            <hr class="border-b-4 logo-border-color mt-5">
        </div>
    </div>

    <div class="container w-full mx-auto px-4 md:px-12">
        <!-- Column -->
        @foreach ($classes as $class)
        <div class="my-2 px-1 w-full lg:my-4 lg:px-4">
        <!-- Article -->
            <article class="overflow-hidden items-center p-6" id="{{$class->id}}">
                <img alt="" class="h-32 w-60 m-auto" src="{{URL::to('/') }}/images/{{$class->images}}">

                <div class="h-auto w-full">
                    <header class="text-center h-12 leading-tight p-2 md:p-4">
                        <h1 class="text-lg logo-text-color font-semibold px-6">
                            {{$class->title}}
                        </h1>
                    </header>
                    <p class="text-center h-12 text-sm sm:text-md px-6 leading-normal">
                        {{$class->description}}
                    </p>
                    <div class="h-auto ml-2 md:ml-4 text-sm sm:text-md px-6 py-6 leading-relaxed">
                        {!!$class->body!!}
                    </div>
                </div>
            </article>
            <!-- END Article -->
        </div>
        @endforeach
    </div>
@endsection