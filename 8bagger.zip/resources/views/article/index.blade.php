@extends('layouts.app')

@section('content')
    <div class="flex justify-center bg-gray-50 mt-10 py-10">
        <div class="text-center w-1/4 mt-10">
            <h1 class="text-4xl sm:text-3xl w-25 font-semibold">
                Article
            </h1>
            <hr class="border-b-4 logo-border-color mt-5">
        </div>
    </div>

    <div class="container w-full mx-auto px-4 md:px-12">
        @foreach ($articles as $article)
            <!-- Column -->
            <div class="my-2 px-1 w-full lg:my-4 lg:px-4">

                <!-- Article -->
                <article class="overflow-hidden grid lg:grid-cols-2 p-6 rounded-lg shadow-lg">
                    <a href="article/detail/{{$article->id}}">
                        <img alt="" class="block h-full w-full" src="{{URL::to('/') }}/images/{{$article->images}}">
                    </a>
                    <div class="block h-auto w-full">
                        <header class="flex block xs:h-12 h-16 leading-tight p-2 md:p-4">
                            <h1 class="text-lg logo-text-color px-6">
                                {{$article->title}}
                            </h1>
                        </header>
                        <p class="block h-auto ml-2 md:ml-4 text-sm sm:text-md px-6 leading-normal">
                            By : {{$article->author}}
                        </p>
                        <p class="block h-auto ml-2 md:ml-4 text-sm sm:text-md px-6 leading-normal">
                            {{$article->date}}
                        </p>
                        <p class="block text-justify h-auto ml-2 md:ml-4 text-sm sm:text-md px-6 py-2 leading-normal">
                            {{$article->summary}}
                        </p>
                        <footer class="flex items-center justify-between leading-none ml-6 p-2 pb-3 md:p-4">
                            <a href="article/detail/{{$article->id}}" class="py-2 text-blue-400 hover:underline">See More</a>
                        </footer>
                    </div>
                </article>
                <!-- END Article -->
            </div>
        @endforeach

        <div class="my-2 px-1 w-full lg:my-4 lg:px-4">
            {{ $articles->links() }}
        </div>
    </div>
    
@endsection