<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Article;

class ArticleController extends Controller
{
    public function getArticle(){
        $articles = Article::orderBy('date','DESC')->paginate(3);
        return view('article.index',compact('articles'));
    }

    public function getDetailArticle($id){
        $articles = Article::find($id);
        return view('article.detail',compact('articles'));
    }

}
