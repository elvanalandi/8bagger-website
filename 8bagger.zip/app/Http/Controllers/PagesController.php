<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index()
    {
        return view('index');
    }

    public function article()
    {
        return view('/article/index');
    }

    public function detail()
    {
        return view('/article/detail');
    }

    public function class()
    {
        return view('/class/index');
    }
}
